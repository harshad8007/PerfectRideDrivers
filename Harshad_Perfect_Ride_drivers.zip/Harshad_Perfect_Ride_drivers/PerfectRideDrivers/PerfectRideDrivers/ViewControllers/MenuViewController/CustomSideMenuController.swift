//
//  CustomSideMenuController.swift
//

import UIKit
import SideMenuController

class CustomSideMenuController: SideMenuController {
	
	required init?(coder aDecoder: NSCoder) {
		SideMenuController.preferences.drawing.menuButtonImage = UIImage(named: "btn_menu")
		SideMenuController.preferences.drawing.sidePanelPosition = .overCenterPanelLeft
		SideMenuController.preferences.drawing.sidePanelWidth = 200 * CGRect.widthRatio
		SideMenuController.preferences.drawing.centerPanelShadow = true
		SideMenuController.preferences.animating.statusBarBehaviour = .showUnderlay
        SideMenuController.preferences.interaction.swipingEnabled = false
        
		super.init(coder: aDecoder)
	}

    override func viewDidLoad() {
        super.viewDidLoad()

		performSegue(withIdentifier: "centerMapContainer", sender: nil)
		performSegue(withIdentifier: "containSideMenu", sender: nil)
        // Do any additional setup after loading the view.  
    }

    override func didReceiveMemoryWarning() {   
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

let SCREEN_WIDTH = UIScreen.main.bounds.size.width
let SCREEN_HEIGHT = UIScreen.main.bounds.size.height

extension CGRect{
    
    static var widthRatio:CGFloat {
        return SCREEN_WIDTH / 320
    }
    
    static var heightRatio:CGFloat {
        return ((max(SCREEN_HEIGHT, 568)) / 568)
    }
}
