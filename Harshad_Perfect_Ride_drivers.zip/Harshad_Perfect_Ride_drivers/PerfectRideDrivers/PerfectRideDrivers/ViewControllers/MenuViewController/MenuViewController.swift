//
//  MenuViewController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

//This view controller used to show side menu options
class MenuViewController: UIViewController {
    
    let cellIdentifier = "MenuCell"
    let cellHeight : CGFloat = 66.0
    let arrTitles = ["Profile","Car Details","Driver information","Bank information"]
    
    @IBOutlet weak var tableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension MenuViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
    //This method called when user clicked on options
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard let navigationController = sideMenuController?.centerViewController.childViewControllers[0].navigationController else{return}
        
        switch indexPath.row {
        case 0:
            guard let profileVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UserProfileController") as? UserProfileController else {return}
            
            navigationController.pushViewController(profileVC, animated: true)
            
        case 1:
            guard let carDetailsVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CarDeatilsViewController") as? CarDeatilsViewController else {return}
            navigationController.pushViewController(carDetailsVC, animated: true)
            
        case 2:
            guard let driverInfoVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DriverInfoViewController") as? DriverInfoViewController else {return}
            navigationController.pushViewController(driverInfoVC, animated: true)
            
        case 3:
            guard let bankInfoVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "BankInfoViewController") as? BankInfoViewController else {return}
            navigationController.pushViewController(bankInfoVC, animated: true)
            
        default:
            break
        }
        sideMenuController?.toggle()
        
        
    }
}

extension MenuViewController: UITableViewDataSource{
    //This method used to set number of sections in a table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //This method used to set number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 	arrTitles.count
    }
    
    //This method used to set table view cell UI
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? SideMenuTableViewCell else{return UITableViewCell()}
        
        cell.setUpCellWith(arrTitles[indexPath.row])
        return cell
    }
    
}
