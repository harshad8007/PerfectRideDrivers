//
//  DriverInfoViewController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

class DriverInfoViewController: UIViewController {

    enum ScreenViewType {
        case view
        case edit
    }
    
    var screenViewType : ScreenViewType = .view
    
    @IBOutlet weak var licenseNumberTxt : UITextField!
    @IBOutlet weak var expiryNumberTxt : UITextField!
    
    @IBOutlet weak var driverDetailsBtn : UIButton!
    @IBOutlet weak var detailsStackView : UIStackView!
    
    var driverInfo : Driver?
    
    //MARK: - View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        switch screenViewType {
        case .edit:
            self.navigationItem.title = "Edit Driver Details"
            addEditNavigationButtons()
            
        case .view:
            self.navigationItem.title = "Driver details"
            addNavigationButton()
            
        }
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //Bellow code used to get driver details from database
        if let dDetails = Driver.getDriverInfoFromContext(params: nil) as? [Driver], dDetails.count > 0{
            driverInfo = dDetails[0]
            setDriverDetailsBasedOn(driverInfo!)
            driverDetailsBtn.isHidden = true
            detailsStackView.isHidden = false
        }else{
            driverDetailsBtn.isHidden = false
            detailsStackView.isHidden = true
        }
        if screenViewType == .edit{
            driverDetailsBtn.isHidden = true
            detailsStackView.isHidden = false
        }
        
    }
    
    //MARK: - Custom methods
    func setDriverDetailsBasedOn(_ driver : Driver) {
        expiryNumberTxt.text = driver.expiry
        licenseNumberTxt.text = driver.licenseNumber
        
    }
    
    //This method used to add cancel and save navigation buttons
    func addEditNavigationButtons(){
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelTapped))
        let saveButton = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveTapped))
        self.navigationItem.leftBarButtonItem = cancelButton
        self.navigationItem.rightBarButtonItem = saveButton
    }
    
    //This method used to add cancel and save navigation buttons
    func addNavigationButton(){
        let editB = UIBarButtonItem(title: "Edit", style: .plain, target: self, action: #selector(editTapped))
        self.navigationItem.rightBarButtonItem = editB
    }
    
    func setUI(){
        driverDetailsBtn.layer.cornerRadius = 5.0
        driverDetailsBtn.layer.masksToBounds = true
        driverDetailsBtn.layer.borderColor = UIColor.black.cgColor
        driverDetailsBtn.layer.borderWidth = 1.0
    }
    
    @objc func editTapped(){
        openInEditMode()
    }
    
    @objc func cancelTapped(){
        self.dismiss(animated: true, completion: nil)
    }
    
    //This method used to save data in core data
    @objc func saveTapped(){
        var dictDetails = [String : String]()
        dictDetails["driverId"] = "0"
        dictDetails["licenseNumber"] = licenseNumberTxt.text ?? ""
        dictDetails["expiry"] = expiryNumberTxt.text ?? ""
        Driver.saveDriverDetailsInDB(dictDetails)
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addDriverDetailsTapped(_ sender: UIButton){
        openInEditMode()
    }
    
    func openInEditMode(){
        guard let driverInfo = self.storyboard?.instantiateViewController(withIdentifier: "DriverInfoViewController") as? DriverInfoViewController else{return}
        driverInfo.screenViewType = .edit
        let navigationController = UINavigationController(rootViewController: driverInfo)
        self.navigationController?.present(navigationController, animated: true, completion: nil)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
