//
//  EditProfileViewController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

//This view contoller is used to edit details of user
class EditProfileViewController: UIViewController {

    @IBOutlet weak var userProfileButton : UIButton!
    @IBOutlet weak var firstNameTxt : UITextField!
    @IBOutlet weak var lastNameTxt : UITextField!
    var selectedImage : UIImage?
    let picker = UIImagePickerController()
    
    //MARK: - View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        addNavigationButtons()
        getUserDetails()
        // Do any additional setup after loading the view.
    }
    
    //MARK: - Custom methods
    //This method used to add cancel and save navigation buttons
    func addNavigationButtons(){
        self.navigationItem.title = "Edit User Profile"
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelTapped))
        let saveButton = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveTapped))
        self.navigationItem.leftBarButtonItem = cancelButton
        self.navigationItem.rightBarButtonItem = saveButton
        
        userProfileButton.layer.cornerRadius = 75.0
        userProfileButton.layer.masksToBounds = true
        userProfileButton.layer.borderColor = UIColor.black.cgColor
        userProfileButton.layer.borderWidth = 1.0
    }
    
    //This method used to get user details from core data
    func getUserDetails(){
        if let userDetails = User.getUserInfoFromContext(params: nil) as? [User], userDetails.count > 0 {
            setUserDetails(user: userDetails[0])
        }
        
    }
    
    //This method used to set user details
    func setUserDetails(user : User){
        lastNameTxt.text = user.lastName
        firstNameTxt.text = user.firstName
        selectedImage = getImageFromString(strBase64: user.profilePhoto)
        userProfileButton.setImage(selectedImage!, for: .normal)
        
    }
    
    //This method used to get image from string
    func getImageFromString(strBase64 : String?) -> UIImage?{
        guard let imageString = strBase64 else{return nil}
        guard let dataDecoded : Data = Data(base64Encoded: imageString, options: .ignoreUnknownCharacters) else{return nil}
        let decodedimage = UIImage(data: dataDecoded)
        return decodedimage
    }
    
    //This method used to close edit profile screen
    @objc func cancelTapped(){
        self.dismiss(animated: true, completion: nil)
    }
    
    //This method used to save user details
    @objc func saveTapped(){
        var dictDetails = [String : String]()
        dictDetails["userId"] = "0"
        dictDetails["lastName"] = lastNameTxt.text ?? ""
        dictDetails["firstName"] = firstNameTxt.text ?? ""
        dictDetails["profilePhoto"] = getStringFrom(image: selectedImage != nil ? selectedImage! : UIImage(named: "profile")!)
        User.saveUserDetailsInDB(dictDetails)
        self.dismiss(animated: true, completion: nil)
    }
    
    func getStringFrom(image : UIImage) -> String {
        guard let imageData:NSData = UIImagePNGRepresentation(image) as NSData? else{return ""}
        let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
        return strBase64
    }
    
    //This method called when user tapped on profile image
    @IBAction func userprofileButtonTapped(_ sender : UIButton){
        picker.allowsEditing = false
        //Checking camera availability
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            picker.sourceType = .camera
        }else{
            picker.sourceType = .photoLibrary
        }
        
        picker.delegate = self
        present(picker, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension EditProfileViewController : UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let chosenImage = info[UIImagePickerControllerOriginalImage] as? UIImage else{
            dismiss(animated: true, completion: nil)
            return
        }
        // use the image
        userProfileButton.setImage(chosenImage, for: .normal)
        selectedImage = chosenImage
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
