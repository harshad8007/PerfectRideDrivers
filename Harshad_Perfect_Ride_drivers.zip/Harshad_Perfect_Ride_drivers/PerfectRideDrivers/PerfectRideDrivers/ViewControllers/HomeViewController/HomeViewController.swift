//
//  HomeViewController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit
import MapKit

//This view controller is used to show user current location.
class HomeViewController: UIViewController {
    
    @IBOutlet weak var mapView : MKMapView!
    @IBOutlet weak var addressTxt : UITextField!
    @IBOutlet weak var locationSwitch : UISwitch!
    var locationManager = CLLocationManager()
    
    //MARK: - View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        setMapDetails()
        // Do any additional setup after loading the view.
    }
    
    //MARK: - Custom Methods
    //This method used to set map view
    func setMapDetails(){
        addressTxt.isUserInteractionEnabled = false		
        mapView.delegate = self
        mapView.showsUserLocation = true
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        
        //Check for Location Services
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
            canGetLocation = false
        }else{
            canGetLocation = true
        }
    
        view.backgroundColor = locationSwitch.isOn ? .green : .red
        addressTxt.isEnabled = locationSwitch.isOn
        
        locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
        
        //Zoom to user location
        let noLocation = CLLocationCoordinate2D()
        let viewRegion = MKCoordinateRegionMakeWithDistance(noLocation, 200, 200)
        mapView.setRegion(viewRegion, animated: false)
        
        DispatchQueue.main.async {
            self.locationManager.startUpdatingLocation()
        }

    }
    
    //This method used to set common set up
    func setUI() {
        self.navigationItem.title = "Home"
        mapView.layer.cornerRadius = 10.0
        mapView.layer.masksToBounds = true
        
    }
    
    //This method called when user changed swift state
    @IBAction func switchValueChanged(_ sender : UISwitch){
        self.view.backgroundColor = sender.isOn ? .green : .red
        mapView.showsUserLocation = sender.isOn
        addressTxt.isEnabled = sender.isOn
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

//Location manager delegate methods
extension HomeViewController : CLLocationManagerDelegate{
    //This method called when user location gets updated.
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let location = userLocation
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        var region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        region.center = mapView.userLocation.coordinate
        mapView.setRegion(region, animated: true)
        getAddressFromLatLon(lat: location.coordinate.latitude, withLongitude: location.coordinate.longitude)
    }
    
    //This method used to get address from lattitude and longitude
    func getAddressFromLatLon(lat: Double, withLongitude long: Double) {
        var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
        let ceo: CLGeocoder = CLGeocoder()
        center.latitude = lat
        center.longitude = long
        let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)
        ceo.reverseGeocodeLocation(loc, completionHandler:{(placemarks, error) in
                if (error != nil){
                    print("reverse geodcode fail: \(error!.localizedDescription)")
                }
                guard let pm = placemarks else{return}
                
                if pm.count > 0 {
                    let pm = placemarks![0]
                    var addressString : String = ""
                    if let strSubLocality = pm.subLocality {
                        addressString = addressString + strSubLocality + ", "
                    }
                    if let strThroughFare = pm.thoroughfare {
                        addressString = addressString + strThroughFare + ", "
                    }
                    if let strLocality = pm.locality {
                        addressString = addressString + strLocality + ", "
                    }
                    if let strCountry = pm.country {
                        addressString = addressString + strCountry + ", "
                    }
                    if let strPostalCode = pm.postalCode {
                        addressString = addressString + strPostalCode + " "
                    }
                    self.addressTxt.text = addressString
                }
        })
    }
}

extension HomeViewController: MKMapViewDelegate{
    
}
