//
//  SideMenuController.h
//  SideMenuController
//
//  Created by Teodor Patras on 16/06/16.
//  Copyright © 2016 teodorpatras. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SideMenuController.
FOUNDATION_EXPORT double SideMenuControllerVersionNumber;

//! Project version string for SideMenuController.
FOUNDATION_EXPORT const unsigned char SideMenuControllerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SideMenuController/PublicHeader.h>


