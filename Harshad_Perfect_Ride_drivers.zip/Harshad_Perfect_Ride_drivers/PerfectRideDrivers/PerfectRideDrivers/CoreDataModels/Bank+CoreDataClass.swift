//
//  Bank+CoreDataClass.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Bank)
public class Bank: NSManagedObject {

    class func getBankInfoFromContext(params:NSPredicate?,sortOn:String? = nil ,isAsending:Bool? = nil) -> [AnyObject]? {
        var sortAry = [NSSortDescriptor]()
        if let sortKey = sortOn {
            let sortDesc = NSSortDescriptor(key: sortKey, ascending: isAsending!, selector:#selector(NSString.localizedCaseInsensitiveCompare(_:)))
            sortAry = [sortDesc]
        }
        return self.getBankSortArrayFromContext(params: params, sortDescAry: sortAry as NSArray?)
    }
    
    class func getBankSortArrayFromContext(params:NSPredicate?,sortDescAry:NSArray? = nil) -> [AnyObject]? {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Bank")
        if let predict = params {
            fetchRequest.predicate = predict
        }
        
        let context = APP_DELEGATE.managedObjectContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Bank", in: (context))
        fetchRequest.entity = entity
        
        if let sortKey = sortDescAry {
            fetchRequest.sortDescriptors = sortKey as? [NSSortDescriptor]
        }
        do {
            let fetchedDreams = try context.fetch(fetchRequest)
            if fetchedDreams.count > 0 {
                return fetchedDreams as [AnyObject]?
            } else {
                return nil
            }
        } catch {
            return nil
        }
    }
    
    class func addNewRecoredInDB(_ bankDetails: [String : String], bank: Bank){
        bank.bankId = bankDetails["bankId"]
        bank.accountNumber = bankDetails["BA"]
        bank.branchNumber = bankDetails["BB"]
        bank.institutionNumber = bankDetails["BI"]
        APP_DELEGATE.saveContext()
    }
    
    class func saveBankDetailsInDB(_ bankDetails: [String : String], isForEdit: Bool = false){
        let predicate = NSPredicate(format: "bankId == '\(bankDetails["bankId"] ?? "0")'")
        var bank: Bank!
        if let arrBankList = Bank.getBankInfoFromContext(params: predicate), arrBankList.count > 0 {
            bank = arrBankList.first as? Bank
        }else{
            if !isForEdit{
                let context = APP_DELEGATE.managedObjectContext
                let entity = NSEntityDescription.entity(forEntityName: "Bank", in: (context))
                bank = Bank(entity: entity!, insertInto: context)
            }
        }
        if bank != nil{
            Bank.addNewRecoredInDB(bankDetails, bank: bank)
        }
    }
    
}
