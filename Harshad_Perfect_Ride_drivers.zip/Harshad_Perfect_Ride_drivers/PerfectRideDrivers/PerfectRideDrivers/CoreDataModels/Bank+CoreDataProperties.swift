//
//  Bank+CoreDataProperties.swift
//  PerfectRideDrivers
//
//  Created by Company Name.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//
//

import Foundation
import CoreData


extension Bank {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Bank> {
        return NSFetchRequest<Bank>(entityName: "Bank")
    }

    @NSManaged public var branchNumber: String?
    @NSManaged public var institutionNumber: String?
    @NSManaged public var accountNumber: String?
    @NSManaged public var bankId: String?
}
