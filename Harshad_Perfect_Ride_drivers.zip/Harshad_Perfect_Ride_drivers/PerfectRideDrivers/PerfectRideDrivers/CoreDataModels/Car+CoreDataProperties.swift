//
//  Car+CoreDataProperties.swift
//  PerfectRideDrivers
//
//  Created by Company Name.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//
//
	
import Foundation
import CoreData


extension Car {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Car> {
        return NSFetchRequest<Car>(entityName: "Car")
    }

    @NSManaged public var make: String?
    @NSManaged public var model: String?
    @NSManaged public var year: String?
    @NSManaged public var carId: String?

}
