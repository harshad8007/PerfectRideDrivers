//
//  Car+CoreDataClass.swift
//  PerfectRideDrivers
//
//  Created by Company Name.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Car)
public class Car: NSManagedObject {
    
    class func getCarInfoFromContext(params:NSPredicate?,sortOn:String? = nil ,isAsending:Bool? = nil) -> [AnyObject]? {
        var sortAry = [NSSortDescriptor]()
        if let sortKey = sortOn {
            let sortDesc = NSSortDescriptor(key: sortKey, ascending: isAsending!, selector:#selector(NSString.localizedCaseInsensitiveCompare(_:)))
            sortAry = [sortDesc]
        }
        return self.getCarSortArrayFromContext(params: params, sortDescAry: sortAry as NSArray?)
    }
    
    class func getCarSortArrayFromContext(params:NSPredicate?,sortDescAry:NSArray? = nil) -> [AnyObject]? {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Car")
        if let predict = params {
            fetchRequest.predicate = predict
        }
        
        let context = APP_DELEGATE.managedObjectContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Car", in: (context))
        fetchRequest.entity = entity
        
        if let sortKey = sortDescAry {
            fetchRequest.sortDescriptors = sortKey as? [NSSortDescriptor]
        }
        do {
            let fetchedDreams = try context.fetch(fetchRequest)
            if fetchedDreams.count > 0 {
                return fetchedDreams as [AnyObject]?
            } else {
                return nil
            }
        } catch {
            return nil
        }
    }
    
    class func addNewRecoredInDB(_ carDetails: [String : String], car: Car){
        car.carId = carDetails["carId"]
        car.year = carDetails["year"]
        car.model = carDetails["model"]
        car.make = carDetails["make"]
        APP_DELEGATE.saveContext()
    }
    
    class func saveCarDetailsInDB(_ carDetails: [String : String], isForEdit: Bool = false){
        let predicate = NSPredicate(format: "carId == '\(carDetails["carId"] ?? "0")'")
        var car: Car!
        if let arrCarList = Car.getCarInfoFromContext(params: predicate), arrCarList.count > 0 {
            car = arrCarList.first as? Car
        }else{
            if !isForEdit{
                let context = APP_DELEGATE.managedObjectContext
                let entity = NSEntityDescription.entity(forEntityName: "Car", in: (context))
                car = Car(entity: entity!, insertInto: context)
            }
        }
        if car != nil{
            Car.addNewRecoredInDB(carDetails, car: car)
        }
    }
    
}
